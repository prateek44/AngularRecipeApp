"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Recipie = (function () {
    function Recipie(name, desc, imgPath) {
        this.name = name;
        this.description = desc;
        this.imagePath = imgPath;
    }
    return Recipie;
}());
exports.Recipie = Recipie;
//# sourceMappingURL=recipie.model.js.map