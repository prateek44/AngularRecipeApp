import { Component, OnInit } from '@angular/core';
import {Recipie} from '../recipie.model';
@Component ({
  selector: 'app-recipies-list',
  templateUrl: './recipies-list.component.html',
  styleUrls: ['./recipies-list.component.css']
})
export class RecipiesListComponent implements OnInit {
  recipies: Recipie[]= [
    new Recipie('Test Recipie', ' this is a dummy recipie' ,
      'https://upload.wikimedia.org/wikipedia/commons/1/15/Recipe_logo.jpeg'
      )
  ]; // holding array of Recipie objects
  constructor() { }
  ngOnInit() {
  }
}
